from django.contrib import admin
from .models import clasificacion,especie

admin.site.register(especie)
admin.site.register(clasificacion)